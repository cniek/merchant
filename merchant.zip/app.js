const express = require('express')
const fetch = require('node-fetch')
const app = express()
const port = 3000

//var index = require('./routes/index');

//app.get('/', (req, res) => res.send('Hello World!'))

//app.listen(port, () => console.log(`Example app listening on port ${port}!`))

/**
 * Module dependencies.
 */

//var express = require('../../');
var path = require('path');

//var app = module.exports = express();

// Register ejs as .html. If we did
// not call this, we would need to
// name our views foo.ejs instead
// of foo.html. The __express method
// is simply a function that engines
// use to hook into the Express view
// system by default, so if we want
// to change "foo.ejs" to "foo.html"
// we simply pass _any_ function, in this
// case `ejs.__express`.

app.engine('.html', require('ejs').__express);

// Optional since express defaults to CWD/views

app.set('views', path.join(__dirname, 'views'));

// Path to our public directory

app.use(express.static(path.join(__dirname, 'public')));

// Without this you would need to
// supply the extension to res.render()
// ex: res.render('users.html').
app.set('view engine', 'html');

// Dummy users
var orders = [
  { _id:"123",coffeetype: 'espresso', size: 'medium',quantity:"1" },
  { _id:"123",coffeetype: 'filter', size: 'small',quantity:"1" },  
];

var id = "";


// Do service calll
//----------------------





//-----------------------------
//----------------------------
app.get('/', function(req, res){
  res.render('orders', {
    orders: orders,
    title: "EJS order example",
    header: "Some orders"
  });
});

//=======================================
app.get('/callBack1', function(req, res){

var data = '';
 console.log(data);
 
var request = require('request');
var url = 'https://directline.botframework.com/v3/directline/conversations';
var headers = {'Content-Type': 'application/json', 'Authorization': 'sBgHJm_vhjo.kNtw3CJbtfQCa3c6qZm2m950Yy301ib_Nxn4WVetiE0'};

  fetch(url, { method: 'POST', headers: headers, body: data})
  .then((rr,res,body) => {

     console.log(body);
     return res.json()
	});
var t = res



//===========================================res





//=======================================


var data = '{ "messages": [ {"to": "27836260714", "content": "Here is an example message", "clientMessageId": "2993b6b548000a80989a20549e7558a6" } ]}';
 console.log(data);
 
var request = require('request');
var url = 'https://platform.clickatell.com/wa/messages';
var headers = {'Content-Type': 'application/json', 'Authorization': 'hxbVZLGSQ9eCSCJzFqXpJQ=='};

  fetch(url, { method: 'POST', headers: headers, body: data})
  .then((res) => {
     console.log('complete2:');
     return res.json()
	});
var t = res


});


//===============================================

app.get('/orders', function(req, res){
  res.render('orders', {
    orders: orders,
    title: "EJS order example",
    header: "Some orders"
  });
});


app.get('/updateOrder', function(req, res){


//})
// var url ='https://order-f738.restdb.io/rest/coffeeorder';
// var headers = { 'cache-control': 'no-cache',
//     'Connection': 'keep-alive',
//     'Accept-Encoding': 'gzip, deflate',
//     'Host': 'order-f738.restdb.io',
//     'Postman-Token': 'ac5b188d-be6b-4047-b9a0-ffba187168ed,aba7f874-69bf-4602-bc83-9de649eeb003',
//     'Cache-Control': 'no-cache',
//     'Accept': '*/*',
//     'User-Agent': 'PostmanRuntime/7.19.0',
//     'Content-Type': 'application/json',
//     'x-api-key': '3dbd96e7cc8695a3ca6ba245c66d726faa892' } 

//fetch(url, { method: 'POST', headers: headers, body:data})
//  .then((res) => {
//     console.log('aaaaaaa');
//     return res.json()
//})
//.then((json) => {
//  console.log(json);
//  orders = json;
//  console.log('orders = json ');

// res.render('orders', {
//    orders: orders,
//    title: "EJS order example",
//    header: "Some orders"
//  });
   
  //return res.json().toString();
  //console.log('ccccc');
  // Do something with the returned data.
//});


//===================================================================================

 var data = "{ '_id': '"+req.query.id+"','status':'complete'}";

   console.log(data);

 var url ='https://order-f738.restdb.io/rest/coffeeorder';
 var headers = { 'cache-control': 'no-cache',
     'Connection': 'keep-alive',
     'Accept-Encoding': 'gzip, deflate',
     'Host': 'order-f738.restdb.io',
     'Postman-Token': 'ac5b188d-be6b-4047-b9a0-ffba187168ed,aba7f874-69bf-4602-bc83-9de649eeb003',
     'Cache-Control': 'no-cache',
     'Accept': '*/*',
     'User-Agent': 'PostmanRuntime/7.19.0',
     'Content-Type': 'application/json',
     'x-api-key': '3dbd96e7cc8695a3ca6ba245c66d726faa892' } 

  fetch(url, { method: 'POST', headers: headers, body: data})
  .then((res) => {
     console.log('complete');
     return res.json()
})
.then((json) => {
  console.log(json);
  orders = json;
  console.log('orders = json ');

 res.render('updateOrder', {
    id: req.query.id,
    title: "Update Buzz Order",
    header: "Buzz order"
  });


});


//===================================================================================

  console.log("Updating Order"+req.query.id);
});

app.get('/apiOrders2', function(req, res){
 var data = '';
 var url ='https://order-f738.restdb.io/rest/coffeeorder';
 var headers = { 'cache-control': 'no-cache',
     'Connection': 'keep-alive',
     'Accept-Encoding': 'gzip, deflate',
     'Host': 'order-f738.restdb.io',
     'Postman-Token': 'ac5b188d-be6b-4047-b9a0-ffba187168ed,aba7f874-69bf-4602-bc83-9de649eeb003',
     'Cache-Control': 'no-cache',
     'Accept': '*/*',
     'User-Agent': 'PostmanRuntime/7.19.0',
     'Content-Type': 'application/json',
     'x-api-key': '3dbd96e7cc8695a3ca6ba245c66d726faa892' } 

fetch(url, { method: 'GET', headers: headers})
  .then((res) => {
     console.log('aaaaaaa');
     return res.json()
})
.then((json) => {
  console.log(json);
  orders = json;
  console.log('orders = json ');

 res.render('orders', {
    orders: orders,
    title: "EJS order example",
    header: "Some orders"
  });
   
  //return res.json().toString();
  //console.log('ccccc');
  // Do something with the returned data.
});
});



/* istanbul ignore next */
if (!module.parent) {
  app.listen(3000);
  console.log('Express started on port 3000');
}
